import SwiftUI

@main
struct S2PassApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
